package com.edtex.bean;

public class Student {
	private String Name;
	private Integer roll;
	private Float ssc;
	private Float hsc;
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public Integer getRoll() {
		return roll;
	}
	public void setRoll(Integer roll) {
		this.roll = roll;
	}
	public Float getSsc() {
		return ssc;
	}
	public void setSsc(Float ssc) {
		this.ssc = ssc;
	}
	public Float getHss() {
		return hsc;
	}
	public void setHss(Float hss) {
		this.hsc = hss;
	}
	
	
}
